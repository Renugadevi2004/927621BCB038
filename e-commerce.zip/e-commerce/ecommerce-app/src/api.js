import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

const api = axios.create({
  baseURL: API_BASE_URL,
});

export const getProducts = async (company, category, topN, minPrice, maxPrice) => {
  const response = await api.get(`/companies/${company}/categories/${category}/products?top-${topN}&minPrice=${minPrice}&maxPrice=${maxPrice}`);
  return response.data;
};

export const getProductById = async (id) => {
  const response = await api.get(`/products/${id}`);
  return response.data;
};
