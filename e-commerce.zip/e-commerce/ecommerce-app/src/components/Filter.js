
import React from 'react';
import { TextField, MenuItem, Grid } from '@mui/material';

const Filter = ({ filters, setFilters }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
    }));
  };

  return (
    <Grid container spacing={2} marginBottom={2}>
      <Grid item xs={12} sm={6} md={3}>
        <TextField
          select
          name="company"
          label="Company"
          value={filters.company}
          onChange={handleChange}
          fullWidth
        >
          <MenuItem value="AMZ">AMZ</MenuItem>
          <MenuItem value="FLP">FLP</MenuItem>
          <MenuItem value="SNP">SNP</MenuItem>
          <MenuItem value="MYN">MYN</MenuItem>
          <MenuItem value="AZO">AZO</MenuItem>
        </TextField>
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <TextField
          select
          name="category"
          label="Category"
          value={filters.category}
          onChange={handleChange}
          fullWidth
        >
          <MenuItem value="Laptop">Laptop</MenuItem>
          <MenuItem value="Phone">Phone</MenuItem>
          {/* Add other categories as needed */}
        </TextField>
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <TextField
          name="minPrice"
          label="Min Price"
          type="number"
          value={filters.minPrice}
          onChange={handleChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <TextField
          name="maxPrice"
          label="Max Price"
          type="number"
          value={filters.maxPrice}
          onChange={handleChange}
          fullWidth
        />
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <TextField
          name="topN"
          label="Top N"
          type="number"
          value={filters.topN}
          onChange={handleChange}
          fullWidth
        />
      </Grid>
    </Grid>
  );
};

export default Filter;
