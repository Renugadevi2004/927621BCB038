import React, { useState, useEffect } from 'react';
import { Card, CardContent, Typography, Button, Grid } from '@mui/material';
import { getProducts } from '../api';
import Filter from './Filter';
import Pagination from './Pagination';
import { Link } from 'react-router-dom';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({
    company: 'AMZ',
    category: 'Laptop',
    minPrice: 0,
    maxPrice: 10000,
    topN: 10,
  });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const fetchProducts = async () => {
      const data = await getProducts(filters.company, filters.category, filters.topN, filters.minPrice, filters.maxPrice);
      setProducts(data);
    };

    fetchProducts();
  }, [filters]);

  // Pagination logic
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <div>
      <Filter filters={filters} setFilters={setFilters} />
      <Grid container spacing={3}>
        {products.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage).map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product.id}>
            <Card>
              <CardContent>
                <Typography variant="h5" component="div">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Company: {product.company}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Category: {product.category}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Price: ${product.price}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Rating: {product.rating}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Discount: {product.discount}%
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Availability: {product.availability ? 'In Stock' : 'Out of Stock'}
                </Typography>
                <Button component={Link} to={`/product/${product.id}`} variant="contained" color="primary">
                  View Details
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
      <Pagination
        totalItems={products.length}
        itemsPerPage={itemsPerPage}
        currentPage={currentPage}
        setCurrentPage={handlePageChange}
      />
    </div>
  );
};

export default ProductList;
