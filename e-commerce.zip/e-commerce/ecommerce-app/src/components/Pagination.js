
import React from 'react';
import { Button, ButtonGroup } from '@mui/material';

const Pagination = ({ totalItems, itemsPerPage, currentPage, setCurrentPage }) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <ButtonGroup variant="contained" color="primary">
      {[...Array(totalPages)].map((_, index) => (
        <Button
          key={index}
          onClick={() => handlePageChange(index + 1)}
          className={index + 1 === currentPage ? 'active' : ''}
        >
          {index + 1}
        </Button>
      ))}
    </ButtonGroup>
  );
};

export default Pagination;
